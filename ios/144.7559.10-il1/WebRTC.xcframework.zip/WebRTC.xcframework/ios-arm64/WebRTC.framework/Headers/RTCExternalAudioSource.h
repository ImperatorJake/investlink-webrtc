/*
 *  InvestLink addition to libwebrtc — the iOS face of
 *  webrtc::ExternalAudioSource. See pc/external_audio_source.h.
 *
 *  Lets an app publish a second audio track carrying something other than the
 *  microphone — on iOS that means app audio arriving from a ReplayKit
 *  Broadcast Upload Extension, which must be its own track rather than mixed
 *  into the mic (the mic path applies AEC/NS/AGC/DTX, all tuned for speech).
 */

#import <CoreMedia/CoreMedia.h>
#import <Foundation/Foundation.h>

#import <WebRTC/RTCAudioSource.h>
#import <WebRTC/RTCMacros.h>
#import <WebRTC/RTCPeerConnectionFactory.h>

NS_ASSUME_NONNULL_BEGIN

RTC_OBJC_EXPORT
@interface RTC_OBJC_TYPE (RTCExternalAudioSource) : NSObject

- (instancetype)init NS_UNAVAILABLE;

/** Create a pushable source belonging to `factory`. */
- (instancetype)initWithFactory:(RTC_OBJC_TYPE(RTCPeerConnectionFactory) *)factory
    NS_DESIGNATED_INITIALIZER;

/**
 * Pass to `-[RTCPeerConnectionFactory audioTrackWithSource:trackId:]`.
 *
 * Holds its own reference, so the track's lifecycle cannot free the source
 * while a capture thread is still pushing into it.
 */
@property(nonatomic, readonly) RTC_OBJC_TYPE(RTCAudioSource) * audioSource;

/**
 * Deliver one 10 ms buffer of interleaved PCM.
 *
 * `frames` must equal `sampleRate / 100`; other lengths are dropped rather
 * than sent, because a mis-sized buffer breaks the encoder's framing rather
 * than merely sounding wrong. Safe to call from a capture thread.
 */
- (void)pushData:(const void *)audioData
    bitsPerSample:(int)bitsPerSample
       sampleRate:(int)sampleRate
         channels:(size_t)channels
           frames:(size_t)frames;

/** Convenience for ReplayKit / AudioUnit callers. Buffer must be PCM. */
- (void)pushSampleBuffer:(CMSampleBufferRef)sampleBuffer;

/**
 * Interleaved PCM of ANY length, accumulated and re-cut into 10 ms frames.
 *
 * For callers holding raw bytes rather than a CMSampleBuffer — the broadcast
 * extension's audio arrives over a socket, already stripped of its sample
 * buffer. Shares the accumulator with `pushSampleBuffer:`, so a caller must use
 * one or the other from a single thread, never both from two.
 */
- (void)pushPCM:(const void *)audioData
            bytes:(size_t)bytes
       sampleRate:(int)sampleRate
         channels:(int)channels
    bitsPerSample:(int)bitsPerSample;

/** Mark the source ended; the track goes to ENDED as a device track would. */
- (void)stop;

@end

NS_ASSUME_NONNULL_END
