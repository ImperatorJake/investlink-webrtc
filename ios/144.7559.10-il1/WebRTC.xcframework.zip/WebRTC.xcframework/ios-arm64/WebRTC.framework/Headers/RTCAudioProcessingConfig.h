/*
 * Copyright 2023 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import <Foundation/Foundation.h>
#import <WebRTC/RTCMacros.h>

NS_ASSUME_NONNULL_BEGIN

RTC_OBJC_EXPORT
@interface RTC_OBJC_TYPE (RTCAudioProcessingConfig) : NSObject 

@property(nonatomic, assign) BOOL isEchoCancellationEnabled;
@property(nonatomic, assign) BOOL isEchoCancellationMobileMode;

@property(nonatomic, assign) BOOL isNoiseSuppressionEnabled;
@property(nonatomic, assign) BOOL isHighpassFilterEnabled;

@property(nonatomic, assign) BOOL isAutoGainControl1Enabled;
@property(nonatomic, assign) BOOL isAutoGainControl2Enabled;


@end

NS_ASSUME_NONNULL_END
